import React, { useState, useEffect } from 'react';
import styles from './Modal.module.css';

// Well-known presets — just for convenience. Users can override everything.
const PRESETS = [
  { label: 'Custom / Other',      base_url: '',                                              adapter: 'openai',    placeholder: 'https://api.yourprovider.com/v1' },
  { label: 'Anthropic (Claude)',  base_url: 'https://api.anthropic.com',                    adapter: 'anthropic', placeholder: 'claude-3-5-haiku-20241022' },
  { label: 'OpenAI (ChatGPT)',    base_url: 'https://api.openai.com/v1',                    adapter: 'openai',    placeholder: 'gpt-4o-mini' },
  { label: 'Google Gemini',       base_url: 'https://generativelanguage.googleapis.com',    adapter: 'gemini',    placeholder: 'gemini-1.5-flash' },
  { label: 'Mistral AI',          base_url: 'https://api.mistral.ai/v1',                    adapter: 'openai',    placeholder: 'mistral-small-latest' },
  { label: 'Groq',                base_url: 'https://api.groq.com/openai/v1',               adapter: 'openai',    placeholder: 'llama-3.1-8b-instant' },
  { label: 'xAI (Grok)',          base_url: 'https://api.x.ai/v1',                          adapter: 'openai',    placeholder: 'grok-2' },
  { label: 'Perplexity',          base_url: 'https://api.perplexity.ai',                    adapter: 'openai',    placeholder: 'llama-3.1-sonar-small-128k-online' },
  { label: 'Together AI',         base_url: 'https://api.together.xyz/v1',                  adapter: 'openai',    placeholder: 'meta-llama/Llama-3-8b-chat-hf' },
  { label: 'Fireworks AI',        base_url: 'https://api.fireworks.ai/inference/v1',        adapter: 'openai',    placeholder: 'accounts/fireworks/models/llama-v3-8b-instruct' },
  { label: 'Ollama (local)',       base_url: 'http://localhost:11434/v1',                    adapter: 'openai',    placeholder: 'llama3.2' },
  { label: 'LM Studio (local)',    base_url: 'http://localhost:1234/v1',                     adapter: 'openai',    placeholder: 'local-model' },
];

export default function ProviderModal({ provider, onSave, onClose, showToast }) {
  const isEdit = !!provider;

  const [preset, setPreset]         = useState(0);
  const [name, setName]             = useState('');
  const [baseUrl, setBaseUrl]       = useState('');
  const [model, setModel]           = useState('');
  const [adapter, setAdapter]       = useState('openai');
  const [apiKey, setApiKey]         = useState('');
  const [quotaDaily, setQuotaDaily] = useState(0);
  const [maxTokens, setMaxTokens]   = useState(2048);
  const [temp, setTemp]             = useState(0.7);
  const [notes, setNotes]           = useState('');
  const [saving, setSaving]         = useState(false);
  const [showKey, setShowKey]       = useState(false);

  useEffect(() => {
    if (provider) {
      setName(provider.name);
      setBaseUrl(provider.base_url);
      setModel(provider.model);
      setAdapter(provider.adapter || 'openai');
      setQuotaDaily(provider.quota_daily || 0);
      setMaxTokens(provider.max_tokens || 2048);
      setTemp(provider.temperature != null ? provider.temperature : 0.7);
      setNotes(provider.notes || '');
      // Load existing key hint
      window.api.keys.get(provider.id).then(k => { if (k) setApiKey('•'.repeat(20)); });
    }
  }, [provider]);

  const applyPreset = (idx) => {
    const p = PRESETS[idx];
    setPreset(idx);
    setAdapter(p.adapter);
    if (p.base_url) setBaseUrl(p.base_url);
    if (!name || name === PRESETS[preset]?.label) setName(p.label !== 'Custom / Other' ? p.label : '');
  };

  const handleSave = async () => {
    if (!name.trim()) { showToast('Name is required', 'warn'); return; }
    if (!baseUrl.trim()) { showToast('Base URL is required', 'warn'); return; }
    if (!model.trim()) { showToast('Model name is required', 'warn'); return; }
    if (!isEdit && !apiKey.trim()) { showToast('API key is required', 'warn'); return; }

    setSaving(true);
    try {
      let savedProvider;
      if (isEdit) {
        savedProvider = await window.api.providers.update({
          id: provider.id,
          name: name.trim(),
          base_url: baseUrl.trim(),
          model: model.trim(),
          adapter,
          quota_daily: parseInt(quotaDaily) || 0,
          max_tokens: parseInt(maxTokens) || 2048,
          temperature: parseFloat(temp),
          notes: notes.trim(),
          enabled: 1,
        });
      } else {
        savedProvider = await window.api.providers.add({
          name: name.trim(),
          base_url: baseUrl.trim(),
          model: model.trim(),
          adapter,
          quota_daily: parseInt(quotaDaily) || 0,
          max_tokens: parseInt(maxTokens) || 2048,
          temperature: parseFloat(temp),
          notes: notes.trim(),
        });
      }

      // Save API key to keychain if changed
      if (apiKey.trim() && !apiKey.startsWith('•')) {
        await window.api.keys.set(savedProvider.id, apiKey.trim());
      }

      onSave();
    } catch (err) {
      showToast(`Error: ${err.message}`, 'danger');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={styles.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <h3>{isEdit ? 'Edit Provider' : 'Add LLM Provider'}</h3>
          <button className={styles.closeBtn} onClick={onClose}>✕</button>
        </div>

        {!isEdit && (
          <div className={styles.formGroup}>
            <label>Quick Setup (optional)</label>
            <select value={preset} onChange={e => applyPreset(Number(e.target.value))}>
              {PRESETS.map((p, i) => (
                <option key={i} value={i}>{p.label}</option>
              ))}
            </select>
            <span className={styles.hint}>Or configure manually below — works with any OpenAI-compatible API</span>
          </div>
        )}

        <div className={styles.row}>
          <div className={styles.formGroup}>
            <label>Display Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="My Claude Account" />
          </div>
          <div className={styles.formGroup} style={{width: 130}}>
            <label>Adapter</label>
            <select value={adapter} onChange={e => setAdapter(e.target.value)}>
              <option value="openai">OpenAI-compat</option>
              <option value="anthropic">Anthropic</option>
              <option value="gemini">Gemini</option>
            </select>
          </div>
        </div>

        <div className={styles.formGroup}>
          <label>Base URL *</label>
          <input
            value={baseUrl}
            onChange={e => setBaseUrl(e.target.value)}
            placeholder={PRESETS[preset]?.placeholder?.startsWith('http') ? PRESETS[preset].placeholder : 'https://api.example.com/v1'}
            spellCheck={false}
          />
          <span className={styles.hint}>The API endpoint. Leave /v1 suffix as required by the provider.</span>
        </div>

        <div className={styles.formGroup}>
          <label>Model Name *</label>
          <input
            value={model}
            onChange={e => setModel(e.target.value)}
            placeholder={!PRESETS[preset]?.placeholder?.startsWith('http') ? PRESETS[preset]?.placeholder : 'model-name-here'}
            spellCheck={false}
          />
          <span className={styles.hint}>Exact model string as required by the provider (e.g. gpt-4o, claude-3-5-haiku-20241022)</span>
        </div>

        <div className={styles.formGroup}>
          <label>API Key {isEdit ? '(leave blank to keep existing)' : '*'}</label>
          <div className={styles.keyWrap}>
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              placeholder={isEdit ? 'Leave blank to keep existing key' : 'Paste your API key…'}
              spellCheck={false}
            />
            <button className={styles.eyeBtn} onClick={() => setShowKey(v => !v)}>
              {showKey ? '🙈' : '👁'}
            </button>
          </div>
          <span className={styles.hint}>🔒 Stored in your OS keychain — never sent anywhere except directly to the provider API</span>
        </div>

        <div className={styles.row}>
          <div className={styles.formGroup}>
            <label>Daily Quota (0 = unlimited)</label>
            <input
              type="number"
              value={quotaDaily}
              onChange={e => setQuotaDaily(e.target.value)}
              min={0}
              placeholder="50"
            />
            <span className={styles.hint}>Auto-disables when reached</span>
          </div>
          <div className={styles.formGroup}>
            <label>Max Tokens</label>
            <input
              type="number"
              value={maxTokens}
              onChange={e => setMaxTokens(e.target.value)}
              min={256}
              max={128000}
            />
          </div>
          <div className={styles.formGroup}>
            <label>Temperature</label>
            <input
              type="number"
              value={temp}
              onChange={e => setTemp(e.target.value)}
              min={0}
              max={2}
              step={0.1}
            />
          </div>
        </div>

        <div className={styles.formGroup}>
          <label>Notes (optional)</label>
          <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="e.g. Free tier — resets monthly" />
        </div>

        <div className={styles.modalActions}>
          <button className={styles.cancelBtn} onClick={onClose}>Cancel</button>
          <button className={styles.saveBtn} onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : isEdit ? 'Save Changes' : 'Add Provider'}
          </button>
        </div>
      </div>
    </div>
  );
}
